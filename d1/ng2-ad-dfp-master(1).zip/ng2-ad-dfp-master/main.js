exports.AdDFPComponent = require('./bundle/ad-dfp').AdDFPComponent;
