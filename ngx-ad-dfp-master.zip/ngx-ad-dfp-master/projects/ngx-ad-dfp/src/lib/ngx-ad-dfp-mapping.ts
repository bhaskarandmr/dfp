export interface NgxAdDfpMapping {
  ad: {
    width: number;
    height: number;
  };
  device: {
    width: number;
    height: number;
  };

}
